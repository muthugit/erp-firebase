<div id="baseErpFooter">
	<hr>
	<center>BASE-ERP</center>
</div>
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

<script src="<?php echo JS_PATH?>bootstrap.min.js"></script>
<script src="<?php echo JS_PATH?>custom.js"></script>
<script src='<?php echo JS_PATH?>firebase.js'></script>
<script src="http://code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script src="<?php echo JS_PATH?>common.js"></script>
<script src="<?php echo JS_PATH?>numberConversion.js"></script>
<script>

</script>
