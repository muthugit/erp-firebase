<hr>
<center>BASE-ERP</center>
<script
	src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?php echo JS_PATH?>bootstrap.min.js"></script>
<script src="<?php echo JS_PATH?>custom.js"></script>
<script src='<?php echo JS_PATH?>firebase.js'></script>
<script>
var erpMain = new Firebase("https://baseerp.firebaseio.com");

function loginWithGoogle(){
	erpMain.authWithOAuthPopup("google", function(error, authData) {
	  if (error) {
		  alert("Login failed");
		  localStorage.setItem("companyId","");
		  window.location.href ="index";
	  } else {
		  var authData = erpMain.getAuth();
		  localStorage.setItem("companyId",authData.uid);
		  window.location.href = "dashboard";
	  }
	});
}
function showInsertItemTab(){
	$("#itemInsertTab").show(1000);	
}

function addItem(){
	
}

function loadItems(){
	
}


</script>
