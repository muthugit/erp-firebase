<html>
<style>
.breadcrumb>li+li:before {
	color: #CCCCCC;
	content: "/ ";
	padding: 0 5px;
}

.pgContainer {
/* 	border: 1px; */
/* 	border-color: black; */
/* 	border-style: solid; */
/* 	border-radius: 4px 4px 4px 4px; */
}

.pgHeader {
	background-color: #2196f3;
	padding: 2%;
	color: white;
	font-size: 20px;
}

.pgInsertTab {
	border: 1px;
	border-color: grey;
	border-style: solid;
	padding: 2%;
	color: white;
	font-size: 20px;
}

.pgHeader-title {
	font-weight: bold;
	text-transform: uppercase;
	font-family: inherit;
	font-weight: 400;
	line-height: 1.1;
}

.pgHeader-content {
	font-family: inherit;
	font-size: 18px;
	font-weight: 300;
	line-height: 1.1;
}
</style>
<head>
<link rel="stylesheet" href="<?php echo CSS_PATH?>bootstrap.min.css">
<link rel="stylesheet" href="<?php echo CSS_PATH?>font-awesome.min.css">
</head>

<style>
.newline {
	padding-bottom: 3%;
}
</style>
<body>
	<a href="<?php echo base_url();?>"><h4 style="padding-left: 2%">BASE
			ERP</h4></a>