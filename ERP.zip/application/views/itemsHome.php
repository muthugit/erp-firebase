<?php
$this->load->view ( 'includes/defaultHeader' );
?>
<ol class="breadcrumb">
	<li><a href="<?php echo base_url();?>">Home</a></li>
	<li><a href="<?php echo base_url();?>dashboard">Dashboard</a></li>
	<li><a href="<?php echo base_url();?>items">Items</a></li>
</ol>
<div class="container">
	<div class="pgContainer">
		<div class="pgHeader col-sm-12">
			<div class="col-sm-4 pgHeader-title">Items</div>
			<div class="col-sm-4 pgHeader-content">2 items</div>
			<div onclick="showInsertItemTab()"
				class="col-sm-4 pgHeader-content text-right">+ Add new</div>
		</div>
		<div id="itemInsertTab" style="display: none"
			class="pgInsertTab form-group col-sm-12">
			<span class="col-sm-6"> <input class="form-control col-sm-2"
				type="text" placeholder="Enter product id" /> <input
				class="form-control" type="text" placeholder="Enter product name" />
				<input class="form-control col-sm-2" type="text"
				placeholder="Cost per unit" />
			</span> <span class="col-sm-6"> <select class="form-control">
					<option value="">Select Product type</option>
					<option value="Product">Product</option>
					<option value="Material">Material</option>
			</select> <select class="form-control">
					<option value="">Select Unit of Measurement</option>
					<option value="piece">Piece</option>
					<option value="kg">KG</option>
			</select>
			</span> <span class="col-sm-12"> <br>
				<center>
					<button class="btn btn-primary">Save</button>
				</center>
			</span>
		</div>
		<div class="col-sm-12 table-responsive">
			<table class="table table-striped col-sm-12">
				<thead>
					<tr>
						<th>Item ID</th>
						<th>Item Name</th>
						<th>Type</th>
						<th>UOM</th>
						<th>Cost per unit</th>
						<th>In stock</th>
						<th>Stock value</th>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>John</td>
						<td>Doe</td>
						<td>john@example.com</td>
						<td>piece</td>
						<td>Rs.10</td>
						<td>1000</td>
						<td>100000</td>
						<td><i class="fa fa-times"></i> / <i class="fa fa-pencil-square-o"></i></td>
					</tr>
					<tr>
						<td>John</td>
						<td>Doe</td>
						<td>john@example.com</td>
						<td><i class="fa fa-times"></i> / <i class="fa fa-pencil-square-o"></i></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php
$this->load->view ( 'includes/defaultFooter' );
?>
