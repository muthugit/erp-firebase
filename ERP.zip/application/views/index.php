<?php
$this->load->view ( 'includes/defaultHeader' );
?>
<div class="breadcrumb">
<a href="<?php echo base_url();?>">Home</a>
</div>
<div class="container">
	<center>
		<button onclick="loginWithGoogle()" class="btn btn-primary btn-lg">Login
			with google</button>
	</center>
</div>
<?php
$this->load->view ( 'includes/defaultFooter' );
?>
<script>
$(function() {
if(localStorage.getItem("companyId")!=""){
	window.location.href = "dashboard";
}
});
</script>