<?php
$this->load->view ( 'includes/defaultHeader' );
?>
<ol class="breadcrumb">
	<li><a href="<?php echo base_url();?>">Home</a></li>
	<li><a href="<?php echo base_url();?>dashboard">Dashboard</a></li>
</ol>
<div class="container">
	<div class="col-sm-2">
		<a href="<?php echo base_url();?>items" class="btn btn-primary">
			<i class="fa fa-anchor  fa-5x"></i>
			<hr>
			Items
		</a>
	</div>
	<div class="col-sm-2">
		<button onclick="" class="btn btn-primary">
			<i class="fa fa-car fa-5x"></i>
			<hr>
			Stock entry
		</button>
	</div>
	<div class="col-sm-2">
		<button onclick="" class="btn btn-primary">
			<i class="fa fa-file-text fa-5x"></i>
			<hr>
			Sales
		</button>
	</div>
</div>
<?php
$this->load->view ( 'includes/defaultFooter' );
?>